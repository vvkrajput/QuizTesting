from django.apps import AppConfig


class QuizApiConfig(AppConfig):
    name = 'quiz_api'
